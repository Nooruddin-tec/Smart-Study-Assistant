# Smart Study Assistant

A complete Python + SQLite study-management project designed to demonstrate
object-oriented thinking, database usage, CRUD operations, analytics, and
real-world software structure.

## Features

- Add and list subjects
- Create study tasks
- Priority levels: Low / Medium / High
- Mark tasks as completed
- Delete tasks
- Record study sessions
- SQLite persistent database
- Progress dashboard
- Daily study goal
- Weak-subject analysis
- Task search
- Clean multi-file architecture
- No external Python packages required

## Requirements

Python 3.9 or newer is recommended.

## Run

Open a terminal inside this folder and run:

```bash
python main.py
```

On some Windows installations you may need:

```bash
py main.py
```

The program automatically creates:

`study_assistant.db`

Do not delete this file if you want to keep your saved data.

## Project architecture

- `main.py` - user interface and program entry point
- `database.py` - SQLite database setup and queries
- `study_manager.py` - subjects, tasks, and study-session operations
- `analytics.py` - progress calculations and reports
- `study_assistant.db` - created automatically at runtime

## Suggested next upgrades

1. Login and multiple student accounts
2. Tkinter graphical interface
3. Charts using Matplotlib
4. Pomodoro timer
5. Notifications
6. Export reports to CSV/PDF
7. REST API with Flask/FastAPI
8. AI-powered study recommendations
9. Cloud database
10. Unit tests and GitHub CI
