from database import Database
from study_manager import StudyManager
from analytics import Analytics


def show_menu():
    print("\n" + "=" * 60)
    print("              SMART STUDY ASSISTANT")
    print("=" * 60)
    print("1. Add subject")
    print("2. List subjects")
    print("3. Add study task")
    print("4. View tasks")
    print("5. Complete task")
    print("6. Delete task")
    print("7. Record study session")
    print("8. View progress dashboard")
    print("9. Find weak subjects")
    print("10. Search tasks")
    print("11. Daily study goal")
    print("12. Exit")
    print("=" * 60)


def choose_priority():
    while True:
        value = input("Priority (Low/Medium/High): ").strip().capitalize()
        if value in {"Low", "Medium", "High"}:
            return value
        print("Please enter Low, Medium, or High.")


def main():
    db = Database("study_assistant.db")
    manager = StudyManager(db)
    analytics = Analytics(db)

    print("\nWelcome to Smart Study Assistant!")
    print("Your data is saved automatically in study_assistant.db")

    while True:
        show_menu()
        choice = input("Choose an option: ").strip()

        try:
            if choice == "1":
                name = input("Subject name: ").strip()
                if not name:
                    print("Subject name cannot be empty.")
                    continue
                manager.add_subject(name)

            elif choice == "2":
                subjects = manager.get_subjects()
                print("\nSUBJECTS")
                print("-" * 40)
                if not subjects:
                    print("No subjects yet.")
                else:
                    for subject in subjects:
                        print(f"{subject['id']}. {subject['name']}")

            elif choice == "3":
                subjects = manager.get_subjects()
                if not subjects:
                    print("Add a subject first.")
                    continue

                print("\nAvailable subjects:")
                for subject in subjects:
                    print(f"{subject['id']}. {subject['name']}")

                subject_id = int(input("Subject ID: "))
                title = input("Task title: ").strip()
                priority = choose_priority()

                manager.add_task(subject_id, title, priority)

            elif choice == "4":
                tasks = manager.get_tasks()
                print("\nTASKS")
                print("-" * 80)
                if not tasks:
                    print("No tasks found.")
                else:
                    for task in tasks:
                        print(
                            f"ID:{task['id']} | "
                            f"{task['subject']} | "
                            f"{task['title']} | "
                            f"{task['priority']} | "
                            f"{task['status']} | "
                            f"{task['created_at']}"
                        )

            elif choice == "5":
                task_id = int(input("Task ID to complete: "))
                if manager.complete_task(task_id):
                    print("Task completed successfully.")
                else:
                    print("Task not found.")

            elif choice == "6":
                task_id = int(input("Task ID to delete: "))
                if manager.delete_task(task_id):
                    print("Task deleted.")
                else:
                    print("Task not found.")

            elif choice == "7":
                subjects = manager.get_subjects()
                if not subjects:
                    print("Add a subject first.")
                    continue

                print("\nAvailable subjects:")
                for subject in subjects:
                    print(f"{subject['id']}. {subject['name']}")

                subject_id = int(input("Subject ID: "))
                minutes = int(input("Study minutes: "))

                if minutes <= 0:
                    print("Minutes must be greater than zero.")
                    continue

                manager.record_session(subject_id, minutes)
                print("Study session recorded.")

            elif choice == "8":
                analytics.show_dashboard()

            elif choice == "9":
                weak = analytics.get_weak_subjects()
                print("\nWEAK SUBJECT ANALYSIS")
                print("-" * 60)

                if not weak:
                    print("Not enough study data yet.")
                else:
                    for item in weak:
                        print(
                            f"{item['subject']}: "
                            f"{item['minutes']} min studied, "
                            f"{item['completion_rate']}% task completion"
                        )

            elif choice == "10":
                keyword = input("Search keyword: ").strip()
                results = manager.search_tasks(keyword)

                if not results:
                    print("No matching tasks.")
                else:
                    print("\nSEARCH RESULTS")
                    print("-" * 70)
                    for task in results:
                        print(
                            f"ID:{task['id']} | "
                            f"{task['subject']} | "
                            f"{task['title']} | "
                            f"{task['priority']} | "
                            f"{task['status']}"
                        )

            elif choice == "11":
                current = analytics.get_daily_goal()
                print(f"\nCurrent daily goal: {current} minutes")

                value = input(
                    "Enter new goal in minutes (press Enter to keep current): "
                ).strip()

                if value:
                    goal = int(value)
                    if goal <= 0:
                        print("Goal must be greater than zero.")
                    else:
                        analytics.set_daily_goal(goal)
                        print(f"Daily goal changed to {goal} minutes.")

            elif choice == "12":
                print("\nGood luck with your learning. Keep building!")
                break

            else:
                print("Invalid option. Choose 1-12.")

        except ValueError:
            print("Please enter a valid number.")
        except Exception as exc:
            print(f"Error: {exc}")


if __name__ == "__main__":
    main()
