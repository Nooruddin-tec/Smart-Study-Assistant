import sqlite3
from pathlib import Path


class Database:
    def __init__(self, db_name="study_assistant.db"):
        self.db_path = Path(db_name)
        self.initialize()

    def connect(self):
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def initialize(self):
        with self.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS subjects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    subject_id INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT NOT NULL CHECK(
                        priority IN ('Low', 'Medium', 'High')
                    ),
                    status TEXT NOT NULL DEFAULT 'Pending' CHECK(
                        status IN ('Pending', 'Completed')
                    ),
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    completed_at TEXT,
                    FOREIGN KEY(subject_id) REFERENCES subjects(id)
                    ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS study_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    subject_id INTEGER NOT NULL,
                    minutes INTEGER NOT NULL CHECK(minutes > 0),
                    studied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(subject_id) REFERENCES subjects(id)
                    ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                INSERT OR IGNORE INTO settings(key, value)
                VALUES ('daily_goal', '120');
            """)

    def execute(self, query, params=(), fetch=False, many=False):
        with self.connect() as conn:
            cursor = conn.cursor()
            if many:
                cursor.executemany(query, params)
            else:
                cursor.execute(query, params)

            if fetch:
                return cursor.fetchall()

            return cursor.lastrowid
