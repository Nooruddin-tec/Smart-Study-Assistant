from datetime import datetime


class StudyManager:
    def __init__(self, database):
        self.db = database

    def add_subject(self, name):
        name = name.strip()
        try:
            self.db.execute(
                "INSERT INTO subjects(name) VALUES (?)",
                (name,)
            )
            print(f"Subject '{name}' added.")
        except Exception:
            print("That subject already exists or could not be added.")

    def get_subjects(self):
        rows = self.db.execute(
            "SELECT id, name FROM subjects ORDER BY name",
            fetch=True
        )
        return [dict(row) for row in rows]

    def add_task(self, subject_id, title, priority):
        title = title.strip()
        if not title:
            print("Task title cannot be empty.")
            return

        subject = self.db.execute(
            "SELECT id FROM subjects WHERE id = ?",
            (subject_id,),
            fetch=True
        )

        if not subject:
            print("Subject not found.")
            return

        self.db.execute(
            """
            INSERT INTO tasks(subject_id, title, priority)
            VALUES (?, ?, ?)
            """,
            (subject_id, title, priority)
        )
        print("Task added.")

    def get_tasks(self):
        rows = self.db.execute(
            """
            SELECT
                tasks.id,
                subjects.name AS subject,
                tasks.title,
                tasks.priority,
                tasks.status,
                tasks.created_at
            FROM tasks
            JOIN subjects ON subjects.id = tasks.subject_id
            ORDER BY
                CASE tasks.status
                    WHEN 'Pending' THEN 0
                    ELSE 1
                END,
                tasks.id DESC
            """,
            fetch=True
        )
        return [dict(row) for row in rows]

    def complete_task(self, task_id):
        existing = self.db.execute(
            "SELECT id FROM tasks WHERE id = ?",
            (task_id,),
            fetch=True
        )
        if not existing:
            return False

        self.db.execute(
            """
            UPDATE tasks
            SET status = 'Completed',
                completed_at = ?
            WHERE id = ?
            """,
            (datetime.now().isoformat(timespec="seconds"), task_id)
        )
        return True

    def delete_task(self, task_id):
        existing = self.db.execute(
            "SELECT id FROM tasks WHERE id = ?",
            (task_id,),
            fetch=True
        )
        if not existing:
            return False

        self.db.execute(
            "DELETE FROM tasks WHERE id = ?",
            (task_id,)
        )
        return True

    def record_session(self, subject_id, minutes):
        subject = self.db.execute(
            "SELECT id FROM subjects WHERE id = ?",
            (subject_id,),
            fetch=True
        )

        if not subject:
            print("Subject not found.")
            return

        self.db.execute(
            """
            INSERT INTO study_sessions(subject_id, minutes)
            VALUES (?, ?)
            """,
            (subject_id, minutes)
        )

    def search_tasks(self, keyword):
        pattern = f"%{keyword}%"
        rows = self.db.execute(
            """
            SELECT
                tasks.id,
                subjects.name AS subject,
                tasks.title,
                tasks.priority,
                tasks.status
            FROM tasks
            JOIN subjects ON subjects.id = tasks.subject_id
            WHERE tasks.title LIKE ?
               OR subjects.name LIKE ?
            ORDER BY tasks.id DESC
            """,
            (pattern, pattern),
            fetch=True
        )
        return [dict(row) for row in rows]
