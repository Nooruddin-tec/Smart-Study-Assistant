from datetime import date


class Analytics:
    def __init__(self, database):
        self.db = database

    def _scalar(self, query, params=()):
        rows = self.db.execute(query, params, fetch=True)
        if not rows:
            return 0
        return rows[0][0] or 0

    def get_daily_goal(self):
        rows = self.db.execute(
            "SELECT value FROM settings WHERE key = 'daily_goal'",
            fetch=True
        )
        return int(rows[0][0]) if rows else 120

    def set_daily_goal(self, minutes):
        self.db.execute(
            """
            INSERT INTO settings(key, value)
            VALUES ('daily_goal', ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """,
            (str(minutes),)
        )

    def today_minutes(self):
        today = date.today().isoformat()
        return self._scalar(
            """
            SELECT COALESCE(SUM(minutes), 0)
            FROM study_sessions
            WHERE DATE(studied_at) = ?
            """,
            (today,)
        )

    def total_minutes(self):
        return self._scalar(
            "SELECT COALESCE(SUM(minutes), 0) FROM study_sessions"
        )

    def total_tasks(self):
        return self._scalar("SELECT COUNT(*) FROM tasks")

    def completed_tasks(self):
        return self._scalar(
            "SELECT COUNT(*) FROM tasks WHERE status = 'Completed'"
        )

    def get_weak_subjects(self):
        rows = self.db.execute(
            """
            SELECT
                subjects.name AS subject,
                COALESCE(
                    (SELECT SUM(minutes)
                     FROM study_sessions s
                     WHERE s.subject_id = subjects.id), 0
                ) AS minutes,
                COALESCE(
                    (
                        SELECT
                            ROUND(
                                100.0 * SUM(
                                    CASE WHEN t.status = 'Completed'
                                    THEN 1 ELSE 0 END
                                ) / COUNT(*), 1
                            )
                        FROM tasks t
                        WHERE t.subject_id = subjects.id
                    ), 0
                ) AS completion_rate
            FROM subjects
            ORDER BY minutes ASC, completion_rate ASC
            """,
            fetch=True
        )

        return [dict(row) for row in rows]

    def show_dashboard(self):
        total = self.total_tasks()
        completed = self.completed_tasks()
        completion_rate = (completed / total * 100) if total else 0

        today = self.today_minutes()
        goal = self.get_daily_goal()
        goal_percent = min(today / goal * 100, 100) if goal else 0

        print("\n" + "=" * 60)
        print("                  PROGRESS DASHBOARD")
        print("=" * 60)
        print(f"Today's study time : {today} minutes")
        print(f"Daily goal         : {goal} minutes")
        print(f"Goal progress      : {goal_percent:.1f}%")
        print(f"Total study time   : {self.total_minutes()} minutes")
        print(f"Total tasks        : {total}")
        print(f"Completed tasks    : {completed}")
        print(f"Task completion    : {completion_rate:.1f}%")
        print("=" * 60)

        subjects = self.get_weak_subjects()
        if subjects:
            print("\nSUBJECT SUMMARY")
            print("-" * 60)
            for item in subjects:
                print(
                    f"{item['subject']:<20} "
                    f"{item['minutes']:>5} min | "
                    f"{item['completion_rate']:>5}% completed"
                )
